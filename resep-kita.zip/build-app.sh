#!/bin/bash
        npm run build
        php artisan storage:link
